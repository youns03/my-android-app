/* ════════════════════════════════════════════════════
   i18n.js — محرك الترجمة
   ════════════════════════════════════════════════════ */

const I18n = (() => {
  let _locale = 'ar';
  let _strings = {};

  // تحميل ملف الترجمة
  async function load(locale) {
    try {
      const res = await fetch(`../i18n/${locale}.json`);
      _strings = await res.json();
      _locale  = locale;
      document.documentElement.lang = locale;
      document.documentElement.dir  = locale === 'ar' ? 'rtl' : 'ltr';
      document.body.dataset.lang    = locale;
      renderAll();
    } catch (e) {
      console.warn('[i18n] failed to load locale:', locale, e);
    }
  }

  // ترجمة مفتاح مع استبدال متغيرات {var}
  function t(key, vars = {}) {
    const keys = key.split('.');
    let val = _strings;
    for (const k of keys) {
      val = val?.[k];
      if (val === undefined) return key;
    }
    return String(val).replace(/\{(\w+)\}/g, (_, k) => vars[k] ?? `{${k}}`);
  }

  // إعادة رسم كل عناصر data-i18n في DOM
  function renderAll() {
    document.querySelectorAll('[data-i18n]').forEach(el => {
      const key = el.dataset.i18n;
      const attr = el.dataset.i18nAttr; // مثال: aria-label
      if (attr) el.setAttribute(attr, t(key));
      else el.textContent = t(key);
    });
    document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
      el.placeholder = t(el.dataset.i18nPlaceholder);
    });
  }

  // تغيير اللغة
  async function setLocale(locale) {
    localStorage.setItem('locale', locale);
    await load(locale);
  }

  // القيمة الحالية
  function getLocale() { return _locale; }

  // تهيئة
  async function init() {
    const saved = localStorage.getItem('locale') || 'ar';
    await load(saved);
  }

  return { init, t, setLocale, getLocale, renderAll };
})();

export default I18n;
