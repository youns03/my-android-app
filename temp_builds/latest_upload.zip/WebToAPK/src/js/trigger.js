/* ════════════════════════════════════════════════════
   trigger.js — استدعاء Cloudflare Worker
   ════════════════════════════════════════════════════ */

const WORKER_URL = '__WORKER_URL__';
const SECRET_KEY = '__SECRET_KEY__';

export async function triggerBuild(zipUrl, options = {}) {
  const res = await fetch(`${WORKER_URL}/trigger`, {
    method:  'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-Secret-Key': SECRET_KEY,
    },
    body: JSON.stringify({
      zip_url:    zipUrl,
      build_type: options.buildType || 'debug',
      source:     'web-app',
    }),
    signal: options.signal,
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok || !data.ok) {
    throw new Error(data.error || `Worker error (${res.status})`);
  }
  return data;  // { ok, run_id, status_url, build_type }
}
