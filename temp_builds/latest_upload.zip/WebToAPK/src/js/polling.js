/* ════════════════════════════════════════════════════
   polling.js — استعلام ذكي مع Exponential Backoff
   الأسلوب المفضل: Callback من Worker (push)
   الاحتياطي:      Polling (pull) بفترات متزايدة
   ════════════════════════════════════════════════════ */

const WORKER_URL = '__WORKER_URL__';
const SECRET_KEY = '__SECRET_KEY__';

const POLL = {
  initial:   6_000,   // 6 ثوانٍ
  max:       20_000,  // 20 ثانية
  factor:    1.4,
  timeout:   30 * 60_000,  // 30 دقيقة
};

// ── pollBuildStatus ────────────────────────────────────
// يُعيد promise يُحلّ عند اكتمال البناء أو يرفض عند الفشل
export async function pollBuildStatus(runId, { onUpdate, signal } = {}) {
  const deadline = Date.now() + POLL.timeout;
  let interval   = POLL.initial;

  while (Date.now() < deadline) {
    if (signal?.aborted) throw new DOMException('Aborted', 'AbortError');

    await sleep(interval);
    if (signal?.aborted) throw new DOMException('Aborted', 'AbortError');

    let status;
    try {
      status = await fetchStatus(runId, signal);
    } catch (err) {
      if (err.name === 'AbortError') throw err;
      console.warn('[polling] خطأ مؤقت، استمرار...', err.message);
      interval = Math.min(interval * POLL.factor, POLL.max);
      continue;
    }

    onUpdate?.(status);

    if (status.status === 'completed') {
      if (status.conclusion === 'success') return status;
      throw new Error(status.error_hint || 'errors.unknown');
    }

    // زيادة تدريجية للفترة
    interval = Math.min(interval * POLL.factor, POLL.max);
  }

  throw new Error('errors.timeout');
}

async function fetchStatus(runId, signal) {
  const res = await fetch(`${WORKER_URL}/status?run_id=${runId}`, {
    headers: { 'X-Secret-Key': SECRET_KEY },
    signal,
  });
  if (!res.ok) throw new Error(`Status error (${res.status})`);
  return res.json();
}

// ── رسائل الحالة للـUI ─────────────────────────────────
export function statusMessage(status) {
  const map = {
    queued:      'في قائمة الانتظار...',
    in_progress: 'البناء جارٍ...',
    completed:   'اكتمل!',
  };
  return map[status] || status;
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
