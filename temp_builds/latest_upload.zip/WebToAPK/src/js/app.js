/* ════════════════════════════════════════════════════
   app.js — المنسّق الرئيسي لكل الوحدات
   ════════════════════════════════════════════════════ */

import I18n      from './i18n.js';
import { validateFile, uploadFile, formatSize, checkHasIndex } from './upload.js';
import { triggerBuild }    from './trigger.js';
import { pollBuildStatus } from './polling.js';
import { downloadAPK, shareAPK } from './download.js';
import { saveBuild, getAllBuilds, clearBuilds, createRecord, formatDate } from './store.js';
import {
  showScreen, setProgress, setStatus, LogViewer,
  showAlert, openModal, closeModal, confirm,
  updateBuildSteps, showSkeleton, Timer
} from './ui.js';

// ══ State ══════════════════════════════════════════════
const state = {
  file:       null,
  zipUrl:     null,
  runId:      null,
  abortCtrl:  null,
  buildStart: null,
  result:     null,
};

// ══ DOM References ═════════════════════════════════════
const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => [...document.querySelectorAll(sel)];

let logViewer, timer;

// ══ Init ═══════════════════════════════════════════════
async function init() {
  await I18n.init();
  bindNavigation();
  bindHomePage();
  bindBuildPage();
  bindHistoryPage();
  bindSettingsPage();

  logViewer = new LogViewer($('#build-log'));
  timer     = new Timer($('#build-elapsed'));

  // Load settings from localStorage
  applySettings();

  showScreen('home');
}

// ══ Navigation ═════════════════════════════════════════
function bindNavigation() {
  $$('[data-nav]').forEach(btn => {
    btn.addEventListener('click', () => {
      const target = btn.dataset.nav;
      if (target === 'history') loadHistory();
      showScreen(target);
    });
  });
}

// ══ HOME PAGE ══════════════════════════════════════════
function bindHomePage() {
  $('#btn-start-home')?.addEventListener('click', () => showScreen('build'));
  $('#btn-history-home')?.addEventListener('click', () => { loadHistory(); showScreen('history'); });
}

// ══ BUILD PAGE ═════════════════════════════════════════
function bindBuildPage() {
  const fileZone   = $('#file-zone');
  const fileInput  = $('#file-input');
  const btnBuild   = $('#btn-start-build');
  const btnRemove  = $('#btn-remove-file');
  const btnCancel  = $('#btn-cancel-build');
  const btnAdvanced= $('#btn-advanced');

  // اختيار ملف
  fileZone?.addEventListener('click', () => fileInput?.click());
  fileInput?.addEventListener('change', (e) => handleFileSelected(e.target.files[0]));

  // Drag & Drop
  fileZone?.addEventListener('dragover',  (e) => { e.preventDefault(); fileZone.classList.add('is-dragover'); });
  fileZone?.addEventListener('dragleave', () => fileZone.classList.remove('is-dragover'));
  fileZone?.addEventListener('drop',      (e) => {
    e.preventDefault();
    fileZone.classList.remove('is-dragover');
    handleFileSelected(e.dataTransfer.files[0]);
  });

  btnRemove?.addEventListener('click', (e) => { e.stopPropagation(); resetFileSelection(); });
  btnBuild?.addEventListener('click', () => startFullBuild());
  btnCancel?.addEventListener('click', () => cancelBuild());

  // Advanced toggle
  btnAdvanced?.addEventListener('click', () => {
    const panel = $('#advanced-panel');
    panel?.classList.toggle('hidden');
    btnAdvanced.textContent = panel?.classList.contains('hidden')
      ? I18n.t('upload.advanced_toggle')
      : '▲ ' + I18n.t('upload.advanced_toggle');
  });

  // زر بناء آخر
  $('#btn-build-another')?.addEventListener('click', () => resetBuildState());

  // زر تنزيل
  $('#btn-download-apk')?.addEventListener('click', () => {
    if (state.result?.githubUrl) downloadAPK(state.result.githubUrl);
  });

  // زر مشاركة
  $('#btn-share-apk')?.addEventListener('click', async () => {
    if (state.result?.githubUrl) {
      const shared = await shareAPK(state.result.githubUrl, state.file?.name || 'app.apk');
      if (!shared) showAlert($('#build-alerts'), { type: 'success', message: 'تم نسخ الرابط!', duration: 2000 });
    }
  });

  // زر عرض السجل الكامل (في شاشة التقدم)
  $('#btn-view-log')?.addEventListener('click', openLogModal);

  // زر عرض السجل الكامل (في شاشة النجاح)
  $('#btn-view-log-done')?.addEventListener('click', openLogModal);
}

// ── اختيار ملف ──────────────────────────────────────
async function handleFileSelected(file) {
  if (!file) return;
  const validation = validateFile(file);
  if (!validation.ok) {
    showAlert($('#file-alerts'), { type: 'error', message: validation.error, closable: true });
    return;
  }
  // تحذير حجم كبير
  if (file.size > 50 * 1024 * 1024) {
    showAlert($('#file-alerts'), { type: 'warning', message: I18n.t('upload.warning_size'), closable: true });
  }
  // فحص وجود index.html
  const hasIndex = await checkHasIndex(file);
  if (!hasIndex) {
    showAlert($('#file-alerts'), { type: 'warning', message: I18n.t('upload.no_index'), closable: true });
  }

  state.file = file;
  updateFileUI(file);
  $('#btn-start-build')?.removeAttribute('disabled');
}

function updateFileUI(file) {
  const zone = $('#file-zone');
  if (!zone) return;
  zone.classList.add('is-selected');
  const info = zone.querySelector('.file-zone__info');
  if (info) {
    info.querySelector('.file-name').textContent = file.name;
    info.querySelector('.file-size').textContent = formatSize(file.size);
    info.classList.remove('hidden');
  }
  zone.querySelector('.file-zone__default')?.classList.add('hidden');
}

function resetFileSelection() {
  state.file = null;
  const zone = $('#file-zone');
  zone?.classList.remove('is-selected', 'is-error');
  zone?.querySelector('.file-zone__info')?.classList.add('hidden');
  zone?.querySelector('.file-zone__default')?.classList.remove('hidden');
  const input = $('#file-input');
  if (input) input.value = '';
  $('#btn-start-build')?.setAttribute('disabled', '');
  $('#file-alerts')?.replaceChildren();
}

// ── تدفق البناء الكامل ───────────────────────────────
async function startFullBuild() {
  if (!state.file) return;
  state.abortCtrl = new AbortController();
  const { signal } = state.abortCtrl;

  logViewer.clear();
  $('#phase-upload').classList.remove('hidden');
  $('#phase-build').classList.add('hidden');
  $('#phase-done').classList.add('hidden');
  $('#btn-start-build')?.setAttribute('disabled', '');

  // ── 1. رفع الملف ──────────────────────────────────
  setStatus($('#build-status-badge'), 'pending');
  updateBuildSteps($('#build-steps'), 'upload');
  logViewer.append(I18n.t('upload.uploading'), 'info');

  let zipUrl;
  try {
    zipUrl = await uploadFile(state.file, {
      signal,
      onProgress: ({ phase, percent, attempt }) => {
        if (phase === 'uploading') {
          setProgress($('#upload-bar'), $('#upload-pct'), percent);
          if (percent === 100) logViewer.append(I18n.t('upload.uploaded'), 'success');
        }
        if (phase === 'retry') {
          logViewer.append(`إعادة المحاولة ${attempt}...`, 'warn');
        }
      }
    });
    state.zipUrl = zipUrl;
    logViewer.append('تم رفع الملف ✓', 'success');
  } catch (err) {
    if (err.name === 'AbortError') return;
    handleBuildError(err.message || I18n.t('errors.network'));
    return;
  }

  // ── 2. تشغيل البناء ───────────────────────────────
  updateBuildSteps($('#build-steps'), 'trigger');
  logViewer.append(I18n.t('build.step_trigger'), 'info');
  setStatus($('#build-status-badge'), 'running');

  let runId;
  try {
    const buildType = $('#select-build-type')?.value || 'debug';
    const res = await triggerBuild(zipUrl, { buildType, signal });
    runId = res.run_id;
    state.runId = runId;
    logViewer.append(`تم تشغيل البناء — Run ID: ${runId}`, 'success');
  } catch (err) {
    if (err.name === 'AbortError') return;
    handleBuildError(err.message);
    return;
  }

  // ── 3. Polling ─────────────────────────────────────
  updateBuildSteps($('#build-steps'), 'gradle');
  $('#phase-upload').classList.add('hidden');
  $('#phase-build').classList.remove('hidden');
  timer.start();

  const phaseMessages = {
    queued:      'في قائمة الانتظار...',
    in_progress: 'البناء جارٍ...',
  };

  try {
    const result = await pollBuildStatus(runId, {
      signal,
      onUpdate: (status) => {
        const msg = phaseMessages[status.status] || '';
        if (msg) logViewer.append(msg, 'info');
        if (status.status === 'completed') updateBuildSteps($('#build-steps'), 'upload_apk');
      }
    });

    const duration = timer.stop();
    logViewer.append('✅ اكتمل البناء بنجاح!', 'success');
    state.result = result;
    showSuccess(result, duration);

  } catch (err) {
    timer.stop();
    if (err.name === 'AbortError') return;
    const key = err.message.startsWith('errors.') ? err.message : 'errors.unknown';
    handleBuildError(I18n.t(key) || err.message);
  }
}

function showSuccess(result, duration) {
  setStatus($('#build-status-badge'), 'succeeded');
  updateBuildSteps($('#build-steps'), 'upload_apk');
  logViewer.append(`⏱ المدة: ${duration}`, 'info');

  $('#phase-build').classList.add('hidden');
  $('#phase-done').classList.remove('hidden');
  $('#download-filename').textContent = state.file?.name?.replace('.zip', '.apk') || 'app-debug.apk';
  $('#download-duration').textContent = duration;
  $('#download-type').textContent = I18n.t('download.type_debug');

  // نسخ السجل إلى ملخص شاشة النجاح
  const summary = $('#build-log-summary');
  if (summary) {
    summary.innerHTML = $('#build-log').innerHTML;
    summary.scrollTop = summary.scrollHeight;
  }

  saveBuild(createRecord({
    fileName:  state.file?.name || 'unknown.zip',
    status:    'success',
    runId:     state.runId,
    githubUrl: result.html_url,
    duration,
    apkSize:   null,
  }));
}

function handleBuildError(message) {
  setStatus($('#build-status-badge'), 'failed');
  logViewer.append(`❌ ${message}`, 'error');
  $('#phase-upload').classList.add('hidden');
  $('#phase-build').classList.add('hidden');
  showAlert($('#build-alerts'), {
    type:    'error',
    title:   I18n.t('build.failed'),
    message,
    closable: true,
  });
  $('#btn-start-build')?.removeAttribute('disabled');
  saveBuild(createRecord({ fileName: state.file?.name || 'unknown.zip', status: 'failed' }));
}

function cancelBuild() {
  confirm(I18n.t('build.cancel_confirm')).then((yes) => {
    if (yes) {
      state.abortCtrl?.abort();
      logViewer.append('تم إلغاء البناء.', 'warn');
      setStatus($('#build-status-badge'), 'cancelled');
    }
  });
}

function resetBuildState() {
  state.file = state.zipUrl = state.runId = state.result = null;
  logViewer.clear();
  resetFileSelection();
  $('#phase-done')?.classList.add('hidden');
  $('#phase-upload')?.classList.remove('hidden');
  setStatus($('#build-status-badge'), 'pending');
  setProgress($('#upload-bar'), $('#upload-pct'), 0);
}

// ══ HISTORY PAGE ═══════════════════════════════════════
async function loadHistory() {
  const container = $('#history-list');
  if (!container) return;
  showSkeleton(container, 3);

  const builds = await getAllBuilds();
  renderHistory(builds, 'all');

  // فلاتر
  $$('[data-filter]').forEach(tab => {
    tab.addEventListener('click', () => {
      $$('[data-filter]').forEach(t => t.classList.remove('is-active'));
      tab.classList.add('is-active');
      renderHistory(builds, tab.dataset.filter);
    });
  });

  // مسح الكل
  $('#btn-clear-history')?.addEventListener('click', async () => {
    const yes = await confirm(I18n.t('history.clear_confirm'));
    if (yes) { await clearBuilds(); renderHistory([], 'all'); }
  });
}

function renderHistory(builds, filter) {
  const container = $('#history-list');
  if (!container) return;

  const filtered = filter === 'all' ? builds
    : builds.filter(b => b.status === ({ ok: 'success', fail: 'failed', run: 'running' }[filter] || filter));

  $('#history-count').textContent = I18n.t('history.subtitle', { count: filtered.length });

  if (filtered.length === 0) {
    container.innerHTML = `
      <div class="empty">
        <div class="empty__icon">📋</div>
        <div class="empty__title">${I18n.t('history.empty_title')}</div>
        <div class="empty__sub">${I18n.t('history.empty_sub')}</div>
      </div>`;
    return;
  }

  container.innerHTML = filtered.map(b => {
    const ok = b.status === 'success';
    return `
    <div class="history-item">
      <div class="history-item__icon history-item__icon--${b.status === 'success' ? 'success' : 'error'}">
        ${ok ? '✓' : '✕'}
      </div>
      <div class="history-item__body">
        <div class="history-item__name">${b.fileName}</div>
        <div class="history-item__meta">${formatDate(b.date)}${b.duration ? ' · ' + b.duration : ''}</div>
      </div>
      ${ok && b.githubUrl ? `
        <button class="btn btn--icon btn--sm" data-url="${b.githubUrl}" aria-label="${I18n.t('history.download')}">
          ↓
        </button>` : ''}
    </div>`;
  }).join('');

  container.querySelectorAll('[data-url]').forEach(btn => {
    btn.addEventListener('click', () => downloadAPK(btn.dataset.url));
  });
}

// ══ SETTINGS PAGE ══════════════════════════════════════
function bindSettingsPage() {
  // مزامنة إعداد نوع البناء بين الشاشتين
  const buildSelects = ['#select-build-type', '#settings-build-type-select'];
  buildSelects.forEach(sel => {
    const el = $(sel);
    if (!el) return;
    el.value = localStorage.getItem('build_type') || 'debug';
    el.addEventListener('change', (e) => {
      localStorage.setItem('build_type', e.target.value);
      // مزامنة الآخر
      buildSelects.forEach(other => {
        const o = $(other);
        if (o && o !== el) o.value = e.target.value;
      });
    });
  });
  // اللغة
  $$('[data-lang]').forEach(btn => {
    btn.addEventListener('click', () => {
      I18n.setLocale(btn.dataset.lang);
      $$('[data-lang]').forEach(b => b.classList.remove('is-active'));
      btn.classList.add('is-active');
    });
  });

  // المظهر
  $$('[data-theme]').forEach(btn => {
    btn.addEventListener('click', () => {
      const theme = btn.dataset.theme;
      document.documentElement.dataset.theme = theme;
      localStorage.setItem('theme', theme);
      $$('[data-theme]').forEach(b => b.classList.remove('is-active'));
      btn.classList.add('is-active');
    });
  });

  // إشعارات
  $('#toggle-notifications')?.addEventListener('change', async (e) => {
    if (e.target.checked && 'Notification' in window) {
      const perm = await Notification.requestPermission();
      if (perm !== 'granted') e.target.checked = false;
    }
    localStorage.setItem('notifications', e.target.checked);
  });
}

function applySettings() {
  const theme = localStorage.getItem('theme') || 'auto';
  document.documentElement.dataset.theme = theme;
  $(`[data-theme="${theme}"]`)?.classList.add('is-active');

  const locale = localStorage.getItem('locale') || 'ar';
  $(`[data-lang="${locale}"]`)?.classList.add('is-active');

  const notif = localStorage.getItem('notifications') === 'true';
  const toggle = $('#toggle-notifications');
  if (toggle) toggle.checked = notif;
}

// ══ Log Modal Helper ═══════════════════════════════════
function openLogModal() {
  const lines = logViewer.getAll().map(l =>
    `<div class="log__line log__line--${l.type}"><span class="log__timestamp">${l.time}</span> ${escapeHtml(l.text)}</div>`
  ).join('');
  openModal(`
    <div class="modal__title" style="margin-bottom:16px">${I18n.t('build.view_full_log')}</div>
    <div class="log" style="max-height:50vh">${lines || '<span style="color:#475569">لا يوجد سجل</span>'}</div>
  `);
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;')
    .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// ══ Start ══════════════════════════════════════════════
document.addEventListener('DOMContentLoaded', init);
