/* ════════════════════════════════════════════════════
   store.js — تخزين السجل محلياً عبر IndexedDB
   ════════════════════════════════════════════════════ */

const DB_NAME    = 'webtopack';
const DB_VERSION = 1;
const STORE_NAME = 'builds';

let _db = null;

async function getDB() {
  if (_db) return _db;
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = (e) => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        const store = db.createObjectStore(STORE_NAME, { keyPath: 'id' });
        store.createIndex('date', 'date', { unique: false });
        store.createIndex('status', 'status', { unique: false });
      }
    };
    req.onsuccess  = (e) => { _db = e.target.result; resolve(_db); };
    req.onerror    = (e) => reject(e.target.error);
  });
}

function txn(mode) {
  return _db.transaction(STORE_NAME, mode).objectStore(STORE_NAME);
}

// حفظ سجل جديد
export async function saveBuild(record) {
  await getDB();
  return new Promise((res, rej) => {
    const req = txn('readwrite').put(record);
    req.onsuccess = () => res();
    req.onerror   = (e) => rej(e.target.error);
  });
}

// جلب كل السجلات مرتبة حسب التاريخ
export async function getAllBuilds() {
  await getDB();
  return new Promise((res, rej) => {
    const req = txn('readonly').index('date').getAll();
    req.onsuccess = (e) => res(e.target.result.reverse());
    req.onerror   = (e) => rej(e.target.error);
  });
}

// حذف كل السجلات
export async function clearBuilds() {
  await getDB();
  return new Promise((res, rej) => {
    const req = txn('readwrite').clear();
    req.onsuccess = () => res();
    req.onerror   = (e) => rej(e.target.error);
  });
}

// إنشاء سجل جديد
export function createRecord({ fileName, status, runId, githubUrl, duration, apkSize }) {
  return {
    id:        runId || crypto.randomUUID(),
    fileName,
    status,    // 'success' | 'failed' | 'running'
    date:      new Date().toISOString(),
    duration:  duration || null,
    apkSize:   apkSize  || null,
    githubUrl: githubUrl || null,
  };
}

// تنسيق التاريخ للعرض
export function formatDate(iso) {
  try {
    return new Intl.DateTimeFormat('ar-SA', {
      year: 'numeric', month: 'short',
      day: 'numeric', hour: '2-digit', minute: '2-digit',
    }).format(new Date(iso));
  } catch { return iso; }
}
