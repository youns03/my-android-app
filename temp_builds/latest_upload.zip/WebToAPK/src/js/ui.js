/* ════════════════════════════════════════════════════
   ui.js — ربط DOM + التنقل + السجل + الإشعارات
   ════════════════════════════════════════════════════ */

import I18n from './i18n.js';

// ══ Screen Router ══════════════════════════════════════
let activeScreen = null;

// للتوافق مع أي استدعاء قديم (لا حاجة لها الآن)
export function registerScreen() {}

export function showScreen(id) {
  // أخفِ الشاشة الحالية
  if (activeScreen) {
    document.getElementById(`screen-${activeScreen}`)?.classList.remove('is-active');
    document.querySelector(`[data-nav="${activeScreen}"]`)?.classList.remove('is-active');
  }
  // أظهر الشاشة الجديدة
  const el = document.getElementById(`screen-${id}`);
  if (el) {
    el.classList.add('is-active');
  } else {
    console.warn(`[ui] showScreen: لا يوجد عنصر بـid="screen-${id}"`);
  }
  document.querySelector(`[data-nav="${id}"]`)?.classList.add('is-active');
  activeScreen = id;
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ══ Progress Bar ════════════════════════════════════════
export function setProgress(barEl, labelEl, percent) {
  if (!barEl) return;
  const clamped = Math.max(0, Math.min(100, percent));
  barEl.style.width = `${clamped}%`;
  barEl.classList.toggle('is-indeterminate', percent < 0);
  if (labelEl) labelEl.textContent = `${clamped}%`;
  barEl.setAttribute('aria-valuenow', clamped);
}

// ══ Status Badge ════════════════════════════════════════
export function setStatus(badgeEl, status) {
  if (!badgeEl) return;
  const map = {
    pending:   ['badge--neutral', I18n.t('build.pending'),   '⏳'],
    running:   ['badge--running', I18n.t('build.running'),   '⚙'],
    succeeded: ['badge--success', I18n.t('build.succeeded'), '✓'],
    failed:    ['badge--error',   I18n.t('build.failed'),    '✕'],
    cancelled: ['badge--neutral', I18n.t('build.cancelled'), '—'],
  };
  const [cls, label, icon] = map[status] || map.pending;
  badgeEl.className = `badge badge--dot ${cls}`;
  badgeEl.textContent = `${icon} ${label}`;
  badgeEl.setAttribute('aria-label', I18n.t('a11y.build_status', { status: label }));
}

// ══ Log Viewer ══════════════════════════════════════════
export class LogViewer {
  constructor(containerEl) {
    this._el   = containerEl;
    this._lines = [];
    if (containerEl) {
      containerEl.setAttribute('role', 'log');
      containerEl.setAttribute('aria-live', 'polite');
      containerEl.setAttribute('aria-label', I18n.t('a11y.log_region'));
    }
  }

  append(text, type = 'info') {
    const time = new Date().toLocaleTimeString('ar', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const entry = { text, type, time };
    this._lines.push(entry);
    if (this._el) {
      const line = document.createElement('div');
      line.className = `log__line log__line--${type}`;
      line.innerHTML = `<span class="log__timestamp">${time}</span>${escapeHtml(text)}`;
      this._el.appendChild(line);
      // اجعل آخر سطر مرئياً
      this._el.scrollTop = this._el.scrollHeight;
      // اجعل السجل مرئي
      this._el.closest('[data-log-wrap]')?.classList.remove('hidden');
    }
  }

  clear() {
    this._lines = [];
    if (this._el) this._el.innerHTML = '';
  }

  getAll() { return [...this._lines]; }
}

// ══ Alert / Toast ════════════════════════════════════════
export function showAlert(containerEl, { type = 'info', title, message, closable = true, duration = 0 }) {
  if (!containerEl) return;
  const alert = document.createElement('div');
  alert.className = `alert alert--${type} animate-fade-in`;
  alert.setAttribute('role', type === 'error' ? 'alert' : 'status');
  const icons = { success: '✓', error: '✕', warning: '⚠', info: 'ℹ' };
  alert.innerHTML = `
    <span class="alert__icon" aria-hidden="true">${icons[type] || 'ℹ'}</span>
    <div class="alert__body">
      ${title ? `<div class="alert__title">${escapeHtml(title)}</div>` : ''}
      ${message ? `<div>${escapeHtml(message)}</div>` : ''}
    </div>
    ${closable ? `<button class="alert__close" aria-label="${I18n.t('a11y.close_modal')}">✕</button>` : ''}
  `;
  if (closable) {
    alert.querySelector('.alert__close').addEventListener('click', () => alert.remove());
  }
  containerEl.innerHTML = '';
  containerEl.appendChild(alert);
  if (duration > 0) setTimeout(() => alert.remove(), duration);
  return alert;
}

// ══ Modal ════════════════════════════════════════════════
export function openModal(html) {
  const backdrop = document.createElement('div');
  backdrop.className = 'modal-backdrop';
  backdrop.setAttribute('role', 'dialog');
  backdrop.setAttribute('aria-modal', 'true');
  backdrop.innerHTML = `
    <div class="modal">
      <div class="modal__handle" aria-hidden="true"></div>
      ${html}
    </div>
  `;
  document.body.appendChild(backdrop);
  // إغلاق بالنقر خارج الـmodal
  backdrop.addEventListener('click', (e) => {
    if (e.target === backdrop) closeModal(backdrop);
  });
  // إغلاق بـEscape
  const onKey = (e) => { if (e.key === 'Escape') closeModal(backdrop); };
  document.addEventListener('keydown', onKey);
  backdrop._removeKey = () => document.removeEventListener('keydown', onKey);
  return backdrop;
}

export function closeModal(backdropEl) {
  backdropEl?._removeKey?.();
  backdropEl?.remove();
}

// ══ Build Steps ══════════════════════════════════════════
const BUILD_STEPS = ['upload', 'trigger', 'gradle', 'upload_apk'];

export function updateBuildSteps(containerEl, activeStep) {
  if (!containerEl) return;
  const activeIdx = BUILD_STEPS.indexOf(activeStep);
  containerEl.querySelectorAll('.build-step').forEach((el, i) => {
    el.className = 'build-step ' + (
      i < activeIdx  ? 'build-step--done' :
      i === activeIdx ? 'build-step--active' : 'build-step--pending'
    );
    const dot = el.querySelector('.build-step__dot');
    if (dot && i < activeIdx) dot.textContent = '✓';
  });
}

// ══ Confirm Dialog ═══════════════════════════════════════
export function confirm(message) {
  return new Promise((resolve) => {
    const modal = openModal(`
      <p class="modal__title" style="margin-bottom:16px">${escapeHtml(message)}</p>
      <div style="display:flex;gap:12px;justify-content:flex-end">
        <button class="btn btn--secondary btn--sm" data-action="no">${I18n.t('build.cancel_no')}</button>
        <button class="btn btn--danger btn--sm" data-action="yes">${I18n.t('build.cancel_yes')}</button>
      </div>
    `);
    modal.addEventListener('click', (e) => {
      const action = e.target.closest('[data-action]')?.dataset.action;
      if (action === 'yes') { closeModal(modal); resolve(true); }
      if (action === 'no')  { closeModal(modal); resolve(false); }
    });
  });
}

// ══ Skeleton ═════════════════════════════════════════════
export function showSkeleton(containerEl, count = 3) {
  if (!containerEl) return;
  containerEl.innerHTML = Array.from({ length: count }, () => `
    <div class="card" style="margin-bottom:12px">
      <div class="skeleton skeleton--title" style="margin-bottom:12px"></div>
      <div class="skeleton skeleton--text" style="width:80%"></div>
      <div class="skeleton skeleton--text" style="width:60%"></div>
    </div>
  `).join('');
}

// ══ Timer ════════════════════════════════════════════════
export class Timer {
  constructor(el) { this._el = el; this._start = null; this._id = null; }
  start() {
    this._start = Date.now();
    this._id = setInterval(() => {
      if (!this._el) return;
      const s = Math.floor((Date.now() - this._start) / 1000);
      const m = Math.floor(s / 60);
      const rem = s % 60;
      this._el.textContent = I18n.t('build.elapsed', {
        duration: m > 0 ? `${m}م ${rem}ث` : `${rem}ث`
      });
    }, 1000);
  }
  stop() {
    clearInterval(this._id);
    this._id = null;
    const s = Math.floor((Date.now() - this._start) / 1000);
    const m = Math.floor(s / 60);
    const r = s % 60;
    return m > 0 ? `${m}م ${r}ث` : `${r}ث`;
  }
}

// ══ Helpers ══════════════════════════════════════════════
function escapeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;')
    .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
