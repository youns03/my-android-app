/* ════════════════════════════════════════════════════
   download.js — تنزيل APK
   ════════════════════════════════════════════════════ */

import I18n from './i18n.js';

// تنزيل عبر رابط مباشر (يفتح رابط GitHub)
export function downloadAPK(url, filename = 'app-debug.apk') {
  if (!url) return;
  // على Android (Capacitor) نفتح رابط GitHub مباشرة
  // المتصفح سيستخدم Download Manager
  const a = document.createElement('a');
  a.href     = url;
  a.download = filename;
  a.target   = '_blank';
  a.rel      = 'noopener noreferrer';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
}

// مشاركة الرابط عبر Web Share API
export async function shareAPK(url, fileName) {
  const shareData = {
    title: I18n.t('app_name'),
    text:  `APK جاهز: ${fileName}`,
    url,
  };
  if (navigator.share && navigator.canShare?.(shareData)) {
    try { await navigator.share(shareData); return true; }
    catch (e) { if (e.name !== 'AbortError') console.warn(e); }
  }
  // fallback: نسخ الرابط
  await copyToClipboard(url);
  return false;
}

async function copyToClipboard(text) {
  try {
    await navigator.clipboard.writeText(text);
  } catch {
    const el = document.createElement('textarea');
    el.value = text;
    el.style.position = 'fixed';
    el.style.opacity  = '0';
    document.body.appendChild(el);
    el.select();
    document.execCommand('copy');
    document.body.removeChild(el);
  }
}
