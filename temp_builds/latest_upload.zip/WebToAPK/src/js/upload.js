/* ════════════════════════════════════════════════════
   upload.js — رفع الملف مع Retry + Progress حقيقي
   ════════════════════════════════════════════════════ */

import I18n from './i18n.js';

const MAX_SIZE_BYTES = 200 * 1024 * 1024;  // 200 MB
const UPLOAD_HOST   = 'https://transfer.sh';
const MAX_RETRIES   = 3;
const RETRY_DELAYS  = [1000, 3000, 7000];   // تأخير متزايد

// ── التحقق من الملف ──────────────────────────────────
export function validateFile(file) {
  if (!file) return { ok: false, error: I18n.t('upload.wrong_type') };
  if (!file.name.toLowerCase().endsWith('.zip'))
    return { ok: false, error: I18n.t('upload.wrong_type') };
  if (file.size > MAX_SIZE_BYTES)
    return { ok: false, error: I18n.t('upload.too_large') };
  return { ok: true };
}

// ── تنسيق الحجم ───────────────────────────────────────
export function formatSize(bytes) {
  if (bytes < 1024)        return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

// ── فحص وجود index.html داخل ZIP (قراءة جزئية) ───────
export async function checkHasIndex(file) {
  return new Promise((resolve) => {
    try {
      const reader = new FileReader();
      reader.onload = (e) => {
        const text = new TextDecoder('utf-8', { fatal: false })
          .decode(new Uint8Array(e.target.result));
        resolve(text.includes('index.html'));
      };
      reader.onerror = () => resolve(true);
      reader.readAsArrayBuffer(file.slice(0, 64 * 1024));
    } catch { resolve(true); }
  });
}

// ── رفع الملف مع Retry ────────────────────────────────
export async function uploadFile(file, { onProgress, signal } = {}) {
  let lastError;

  for (let attempt = 0; attempt < MAX_RETRIES; attempt++) {
    try {
      if (attempt > 0) {
        const delay = RETRY_DELAYS[attempt - 1];
        onProgress?.({ phase: 'retry', attempt, delay, percent: 0 });
        await sleep(delay);
      }
      const url = await uploadAttempt(file, { onProgress, signal });
      return url;
    } catch (err) {
      if (err.name === 'AbortError') throw err;
      lastError = err;
      console.warn(`[upload] محاولة ${attempt + 1} فشلت:`, err.message);
    }
  }

  throw new Error(lastError?.message || I18n.t('errors.network'));
}

function uploadAttempt(file, { onProgress, signal }) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();

    // تقدم حقيقي عبر xhr.upload.onprogress
    xhr.upload.onprogress = (e) => {
      if (!e.lengthComputable) return;
      const percent = Math.round((e.loaded / e.total) * 100);
      onProgress?.({ phase: 'uploading', percent, loaded: e.loaded, total: e.total });
    };

    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) {
        const url = xhr.responseText.trim();
        if (!url.startsWith('https://'))
          reject(new Error('الرابط المُعاد غير صالح'));
        else resolve(url);
      } else {
        reject(new Error(`فشل الرفع (${xhr.status})`));
      }
    };

    xhr.onerror   = () => reject(new Error(I18n.t('errors.network')));
    xhr.ontimeout = () => reject(new Error('انتهت مهلة الرفع'));
    xhr.timeout   = 180_000;  // 3 دقائق

    if (signal) {
      signal.addEventListener('abort', () => {
        xhr.abort();
        reject(new DOMException('AbortError', 'AbortError'));
      });
    }

    xhr.open('PUT', `${UPLOAD_HOST}/${encodeURIComponent(file.name)}`);
    xhr.send(file);
  });
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
