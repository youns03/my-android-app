# WebToAPK — المشروع الكامل

> حوّل مشروع ويب (ZIP) إلى تطبيق Android (APK) مجاناً بالكامل.

---

## هيكل المشروع

```
WebToAPK/
│
├── 🌐 src/                          ← واجهة الويب (Front-end)
│   ├── index.html                   ← هيكل التطبيق الكامل
│   ├── styles/
│   │   ├── variables.css            ← نظام التصميم (ألوان، خطوط، مسافات)
│   │   ├── base.css                 ← Reset + Typography + RTL
│   │   ├── components.css           ← أزرار، بطاقات، شريط التقدم، ...
│   │   └── layout.css               ← Header، Footer، الصفحات
│   ├── js/
│   │   ├── app.js                   ← المنسّق الرئيسي
│   │   ├── i18n.js                  ← محرك الترجمة
│   │   ├── upload.js                ← رفع الملف مع تقدم وإعادة محاولة
│   │   ├── trigger.js               ← استدعاء Cloudflare Worker
│   │   ├── polling.js               ← استعلام حالة البناء (Exponential Backoff)
│   │   ├── download.js              ← تنزيل ومشاركة APK
│   │   ├── store.js                 ← سجل محلي (IndexedDB)
│   │   └── ui.js                    ← ربط DOM + التنقل + اللوغ + المودال
│   └── i18n/
│       ├── ar.json                  ← الترجمة العربية
│       └── en.json                  ← الترجمة الإنجليزية
│
├── 📱 android/                      ← تطبيق Android (Jetpack Compose)
│   └── app/src/main/
│       ├── java/com/example/webtopack/
│       │   ├── MainActivity.kt      ← الواجهة (Compose)
│       │   ├── MainViewModel.kt     ← إدارة الحالة + السجل
│       │   └── BuildManager.kt      ← الشبكة
│       └── AndroidManifest.xml
│
├── ⚙️  build-from-zip.yml           ← GitHub Actions (14 خطوة)
├── ☁️  worker.js                    ← Cloudflare Worker
├── 🔧 wrangler.toml                 ← إعداد Cloudflare
└── 📖 README.md
```

---

## الخطوات (بالترتيب)

### 1. إعداد GitHub
1. أنشئ مستودعاً جديداً
2. ضع `.github/workflows/build-from-zip.yml` فيه
3. أنشئ Personal Access Token (scopes: `repo` + `workflow`)

### 2. نشر Cloudflare Worker
```bash
npm install -g wrangler
wrangler login
# عدّل wrangler.toml: ضع اسمك وريبو GitHub
wrangler secret put GITHUB_TOKEN
wrangler secret put SECRET_KEY
wrangler deploy
```

### 3. تشغيل واجهة الويب
1. افتح `src/index.html` في المتصفح مباشرة
2. أو استضفها على GitHub Pages / Netlify / Vercel مجاناً
3. عدّل `WORKER_URL` و `SECRET_KEY` في `src/js/trigger.js` و `src/js/polling.js`

### 4. تطبيق Android (اختياري)
1. افتح مجلد `android/` في Android Studio
2. عدّل `BuildManager.kt`: ضع `WORKER_URL` و `SECRET_KEY`
3. شغّل على هاتفك

---

## شاشات التطبيق

| الشاشة | الوصف |
|--------|-------|
| 🏠 الرئيسية | شرح الوظيفة + زر البدء + كيف يعمل |
| 🔨 البناء | رفع الملف + شريط تقدم + مؤشر الخطوات + سجل حي |
| ✅ التنزيل | زر تنزيل APK + مشاركة الرابط |
| 📋 السجل | كل البناءات السابقة مع فلاتر |
| ⚙️ الإعدادات | اللغة + المظهر + الإشعارات |

---

## ميزات الواجهة

- ✅ **RTL كامل** — دعم العربية بشكل أصيل
- ✅ **ثنائي اللغة** — AR / EN مع تبديل فوري
- ✅ **موبايل-فيرست** — مُصمَّم للهاتف أولاً
- ✅ **وضع داكن/فاتح** — تلقائي أو يدوي
- ✅ **إمكانية الوصول** — WCAG AA، aria-live، skip links
- ✅ **Retry تلقائي** — 3 محاولات مع تأخير متزايد
- ✅ **سجل محلي** — IndexedDB بدون خادم
- ✅ **تحقق من الملف** — النوع، الحجم، وجود index.html
