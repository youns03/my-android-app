package com.example.webtopack

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit

// ════════════════════════════════════════════
//  CONFIG — ← ضع قيمك هنا
// ════════════════════════════════════════════
private const val WORKER_URL  = "https://zip-to-apk-worker.YOUR_SUBDOMAIN.workers.dev"
private const val SECRET_KEY  = "YOUR_SECRET_KEY"
private const val UPLOAD_HOST = "https://transfer.sh"

// ════════════════════════════════════════════
//  MODELS
// ════════════════════════════════════════════
data class BuildProgress(val phase: String, val message: String, val percent: Int)

sealed class BuildResult {
    data class Success(val runId: String, val githubUrl: String, val apkSize: String?) : BuildResult()
    data class Failure(val message: String) : BuildResult()
}

// ════════════════════════════════════════════
//  BUILD MANAGER
// ════════════════════════════════════════════
class BuildManager {

    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(120, TimeUnit.SECONDS)
        .build()

    suspend fun buildFromZip(
        zipFile: File,
        onProgress: suspend (BuildProgress) -> Unit
    ): BuildResult = withContext(Dispatchers.IO) {

        // ── 1. رفع الملف ────────────────────────────────────────
        onProgress(BuildProgress("uploading", "جاري رفع الملف...", 0))
        val zipUrl = uploadFile(zipFile) { pct ->
            onProgress(BuildProgress("uploading", "رفع الملف... $pct%", pct))
        }

        // ── 2. تشغيل البناء عبر Worker ──────────────────────────
        onProgress(BuildProgress("triggering", "تشغيل خط البناء...", 0))
        val triggerResp = triggerWorker(zipUrl)
        val runId = triggerResp.optString("run_id").ifBlank { null }
            ?: return@withContext BuildResult.Failure("لم يُعثر على run_id من الـWorker")

        // ── 3. Polling ───────────────────────────────────────────
        val messages = listOf(
            "الخادم استقبل الطلب...",
            "تحميل القالب...",
            "فك ضغط ملفات الويب...",
            "نسخ الملفات إلى assets...",
            "إعداد Java 17...",
            "تحميل Gradle...",
            "تجميع الكود...",
            "إنشاء Debug APK...",
            "رفع النتيجة..."
        )
        var msgIdx = 0

        repeat(45) { attempt ->
            delay(8_000)
            val estimatedPct = minOf(10 + attempt * 4, 90)
            val msg = messages.getOrElse(msgIdx++) { "البناء جارٍ..." }
            onProgress(BuildProgress("building", msg, estimatedPct))

            val status = fetchStatus(runId) ?: return@repeat

            when (status.optString("status")) {
                "completed" -> {
                    return@withContext when (status.optString("conclusion")) {
                        "success" -> {
                            onProgress(BuildProgress("done", "اكتمل البناء!", 100))
                            BuildResult.Success(
                                runId     = runId,
                                githubUrl = status.optString("html_url").ifBlank {
                                    "https://github.com/actions/runs/$runId"
                                },
                                apkSize   = null
                            )
                        }
                        "failure"   -> BuildResult.Failure("فشل البناء — تحقق من GitHub Actions")
                        "cancelled" -> BuildResult.Failure("تم إلغاء البناء")
                        else        -> BuildResult.Failure("حالة غير متوقعة: ${status.optString("conclusion")}")
                    }
                }
            }
        }

        BuildResult.Failure("انتهت مهلة الانتظار (6 دقائق) — تحقق من GitHub Actions يدوياً")
    }

    // ── رفع إلى transfer.sh ─────────────────────────────────────
    private fun uploadFile(file: File, onPercent: (Int) -> Unit): String {
        val body = object : RequestBody() {
            override fun contentType() = "application/zip".toMediaTypeOrNull()
            override fun contentLength() = file.length()
            override fun writeTo(sink: okio.BufferedSink) {
                val total = file.length().coerceAtLeast(1)
                var sent = 0L
                file.inputStream().use { input ->
                    val buf = ByteArray(8192)
                    var read: Int
                    while (input.read(buf).also { read = it } != -1) {
                        sink.write(buf, 0, read)
                        sent += read
                        onPercent((sent * 100 / total).toInt())
                    }
                }
            }
        }
        val req  = Request.Builder().url("$UPLOAD_HOST/${file.name}").put(body).build()
        val resp = http.newCall(req).execute()
        if (!resp.isSuccessful) throw IOException("فشل رفع الملف (${resp.code})")
        return resp.body?.string()?.trim() ?: throw IOException("لم يُعد رابط من transfer.sh")
    }

    // ── استدعاء Worker ──────────────────────────────────────────
    private fun triggerWorker(zipUrl: String): JSONObject {
        val body = JSONObject().put("zip_url", zipUrl).put("source", "android-personal")
            .toString().toRequestBody("application/json".toMediaTypeOrNull())
        val req  = Request.Builder()
            .url("$WORKER_URL/trigger")
            .addHeader("X-Secret-Key", SECRET_KEY)
            .post(body).build()
        val resp = http.newCall(req).execute()
        val text = resp.body?.string() ?: "{}"
        if (!resp.isSuccessful) throw IOException("خطأ من الـWorker (${resp.code}): $text")
        return JSONObject(text)
    }

    // ── جلب حالة Run ────────────────────────────────────────────
    private fun fetchStatus(runId: String): JSONObject? {
        return try {
            val req  = Request.Builder()
                .url("$WORKER_URL/status?run_id=$runId")
                .addHeader("X-Secret-Key", SECRET_KEY)
                .get().build()
            val resp = http.newCall(req).execute()
            if (!resp.isSuccessful) return null
            resp.body?.string()?.let { JSONObject(it) }
        } catch (e: Exception) { null }
    }
}
