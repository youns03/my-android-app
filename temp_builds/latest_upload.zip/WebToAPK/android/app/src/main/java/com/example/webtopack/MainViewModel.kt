package com.example.webtopack

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

// ════════════════════════════════════════════
//  DATA CLASSES
// ════════════════════════════════════════════
data class BuildRecord(
    val id: String,
    val fileName: String,
    val status: String,        // "success" | "failed"
    val date: String,
    val duration: String,
    val apkSize: String,
    val githubUrl: String?
)

// ════════════════════════════════════════════
//  UI STATES
// ════════════════════════════════════════════
sealed class BuildUiState {
    object Idle : BuildUiState()
    data class InProgress(val phase: String, val message: String, val percent: Int) : BuildUiState()
    data class Success(val runId: String, val githubUrl: String, val duration: String, val apkSize: String) : BuildUiState()
    data class Error(val message: String) : BuildUiState()
}

// ════════════════════════════════════════════
//  VIEWMODEL
// ════════════════════════════════════════════
class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val manager = BuildManager()
    private val prefs   = app.getSharedPreferences("build_history", android.content.Context.MODE_PRIVATE)

    private val _uiState = MutableStateFlow<BuildUiState>(BuildUiState.Idle)
    val uiState: StateFlow<BuildUiState> = _uiState

    private val _logs = MutableStateFlow<List<String>>(emptyList())
    val logs: StateFlow<List<String>> = _logs

    private val _history = MutableStateFlow<List<BuildRecord>>(loadHistory())
    val history: StateFlow<List<BuildRecord>> = _history

    // ── بدء البناء ───────────────────────────────────────────────
    fun startBuild(zipFile: File) {
        viewModelScope.launch {
            val startTime = System.currentTimeMillis()
            _logs.value = emptyList()
            addLog("بدء البناء: ${zipFile.name}")

            try {
                val result = manager.buildFromZip(zipFile) { progress ->
                    _uiState.value = BuildUiState.InProgress(
                        phase   = progress.phase,
                        message = progress.message,
                        percent = progress.percent
                    )
                    addLog(progress.message)
                }

                val elapsed = formatDuration(System.currentTimeMillis() - startTime)

                when (result) {
                    is BuildResult.Success -> {
                        addLog("✅ اكتمل البناء في $elapsed")
                        _uiState.value = BuildUiState.Success(
                            runId     = result.runId,
                            githubUrl = result.githubUrl,
                            duration  = elapsed,
                            apkSize   = result.apkSize ?: "—"
                        )
                        saveToHistory(BuildRecord(
                            id         = result.runId,
                            fileName   = zipFile.name,
                            status     = "success",
                            date       = today(),
                            duration   = elapsed,
                            apkSize    = result.apkSize ?: "—",
                            githubUrl  = result.githubUrl
                        ))
                    }
                    is BuildResult.Failure -> {
                        addLog("❌ فشل: ${result.message}")
                        _uiState.value = BuildUiState.Error(result.message)
                        saveToHistory(BuildRecord(
                            id        = UUID.randomUUID().toString().take(8),
                            fileName  = zipFile.name,
                            status    = "failed",
                            date      = today(),
                            duration  = elapsed,
                            apkSize   = "—",
                            githubUrl = null
                        ))
                    }
                }
            } catch (e: Exception) {
                val msg = e.message ?: "خطأ غير متوقع"
                addLog("❌ $msg")
                _uiState.value = BuildUiState.Error(msg)
            }
        }
    }

    fun reset() { _uiState.value = BuildUiState.Idle }

    fun clearHistory() {
        _history.value = emptyList()
        prefs.edit().clear().apply()
    }

    // ── Log ──────────────────────────────────────────────────────
    private fun addLog(msg: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        _logs.value = _logs.value + "[$time] $msg"
    }

    // ── Persistence ──────────────────────────────────────────────
    private fun saveToHistory(record: BuildRecord) {
        val current = _history.value.toMutableList()
        current.add(0, record)
        _history.value = current.take(20) // أبقِ آخر 20 فقط
        // حفظ بسيط عبر SharedPreferences
        val json = current.take(20).joinToString("|") {
            "${it.id}§${it.fileName}§${it.status}§${it.date}§${it.duration}§${it.apkSize}§${it.githubUrl ?: ""}"
        }
        prefs.edit().putString("records", json).apply()
    }

    private fun loadHistory(): List<BuildRecord> {
        val raw = prefs.getString("records", "") ?: return emptyList()
        if (raw.isBlank()) return emptyList()
        return raw.split("|").mapNotNull { row ->
            val p = row.split("§")
            if (p.size < 7) null
            else BuildRecord(p[0], p[1], p[2], p[3], p[4], p[5], p[6].ifBlank { null })
        }
    }

    private fun today() = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    private fun formatDuration(ms: Long): String {
        val s = ms / 1000
        return if (s < 60) "${s}ث" else "${s / 60}م ${s % 60}ث"
    }
}
