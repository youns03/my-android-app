package com.example.webtopack

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import java.io.File

// ════════════════════════════════════════════
//  COLORS
// ════════════════════════════════════════════
private val Cyan    = Color(0xFF00E5FF)
private val Blue    = Color(0xFF0066FF)
private val BgDark  = Color(0xFF080C14)
private val Sfc     = Color(0xFF0E1420)
private val Border  = Color(0xFF1A2235)
private val Muted   = Color(0xFF4A5568)
private val Green   = Color(0xFF00E676)
private val Red     = Color(0xFFFF5555)

// ════════════════════════════════════════════
//  MainActivity
// ════════════════════════════════════════════
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppTheme { AppRoot() } }
    }
}

@Composable
fun AppRoot(vm: MainViewModel = viewModel()) {
    var tab by remember { mutableIntStateOf(0) }
    Scaffold(
        containerColor = BgDark,
        bottomBar = {
            NavigationBar(containerColor = Sfc, tonalElevation = 0.dp,
                modifier = Modifier.border(BorderStroke(1.dp, Border), RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
            ) {
                listOf(Triple(Icons.Default.Build, "بناء", 0), Triple(Icons.Default.History, "السجل", 1)).forEach { (icon, label, idx) ->
                    NavigationBarItem(
                        selected = tab == idx, onClick = { tab = idx },
                        icon = { Icon(icon, null) }, label = { Text(label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Cyan, selectedTextColor = Cyan,
                            unselectedIconColor = Muted, unselectedTextColor = Muted,
                            indicatorColor = Sfc
                        )
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            when (tab) { 0 -> BuildScreen(vm); 1 -> HistoryScreen(vm) }
        }
    }
}

// ════════════════════════════════════════════
//  BUILD SCREEN
// ════════════════════════════════════════════
@Composable
fun BuildScreen(vm: MainViewModel) {
    val state   by vm.uiState.collectAsStateWithLifecycle()
    val context  = LocalContext.current
    var file     by remember { mutableStateOf<File?>(null) }
    var fileName by remember { mutableStateOf<String?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let {
            val tmp = File(context.cacheDir, "up_${System.currentTimeMillis()}.zip")
            context.contentResolver.openInputStream(uri)?.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
            file = tmp
            fileName = getFileName(context, uri)
        }
    }

    LazyColumn(
        Modifier.fillMaxSize().background(BgDark),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header
        item {
            Column(Modifier.padding(top = 16.dp, bottom = 8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("⬡", fontSize = 22.sp, color = Cyan)
                    Text("WebToAPK", fontSize = 26.sp, fontWeight = FontWeight.Black, color = Color.White)
                }
                Text("حوّل مشروع الويب إلى APK", fontSize = 13.sp, color = Muted, modifier = Modifier.padding(top = 2.dp))
            }
        }

        // ── IDLE / ERROR ──────────────────────────────────
        if (state is BuildUiState.Idle || state is BuildUiState.Error) {

            item { FilePickerCard(fileName, { picker.launch("application/zip") }, { file = null; fileName = null }) }

            if (state is BuildUiState.Error) item { ErrorBanner((state as BuildUiState.Error).message) }

            item {
                Button(
                    onClick = { file?.let { vm.startBuild(it) } },
                    enabled = file != null,
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Cyan, disabledContainerColor = Border)
                ) {
                    Text("🚀  ابدأ البناء", color = if (file != null) Color.Black else Muted,
                        fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                }
            }
        }

        // ── IN PROGRESS ───────────────────────────────────
        if (state is BuildUiState.InProgress) {
            val s = state as BuildUiState.InProgress
            item { ProgressCard(s) }
            item { LogCard(vm.logs) }
        }

        // ── SUCCESS ───────────────────────────────────────
        if (state is BuildUiState.Success) {
            val s = state as BuildUiState.Success
            item { SuccessCard(s, context) }
            item { LogCard(vm.logs) }
            item {
                OutlinedButton(
                    onClick = { vm.reset(); file = null; fileName = null },
                    modifier = Modifier.fillMaxWidth(),
                    border = BorderStroke(1.dp, Border), shape = RoundedCornerShape(12.dp)
                ) { Text("بناء مشروع آخر", color = Muted) }
            }
        }
    }
}

// ════════════════════════════════════════════
//  FILE PICKER CARD
// ════════════════════════════════════════════
@Composable
fun FilePickerCard(fileName: String?, onPick: () -> Unit, onClear: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().height(150.dp)
            .clip(RoundedCornerShape(16.dp))
            .border(BorderStroke(2.dp, if (fileName != null) Cyan else Border), RoundedCornerShape(16.dp))
            .background(Sfc).clickable(onClick = onPick),
        contentAlignment = Alignment.Center
    ) {
        if (fileName != null) {
            Row(verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.padding(horizontal = 16.dp)) {
                Text("📦", fontSize = 30.sp)
                Column(Modifier.weight(1f)) {
                    Text(fileName, color = Cyan, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("انقر لتغيير الملف", color = Muted, fontSize = 12.sp)
                }
                IconButton(onClick = onClear) { Icon(Icons.Default.Close, null, tint = Muted) }
            }
        } else {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("⬆", fontSize = 34.sp)
                Text("اختر ملف ZIP", color = Muted, fontWeight = FontWeight.Medium)
                Text("HTML · CSS · JS", color = Color(0xFF1E2D3D), fontSize = 12.sp)
            }
        }
    }
}

// ════════════════════════════════════════════
//  PROGRESS CARD
// ════════════════════════════════════════════
@Composable
fun ProgressCard(s: BuildUiState.InProgress) {
    val inf = rememberInfiniteTransition(label = "")
    val alpha by inf.animateFloat(0.5f, 1f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "")
    val phaseLabel = mapOf("uploading" to "⬆  رفع الملف", "triggering" to "⚙  تشغيل البناء", "building" to "🔨  البناء جارٍ")[s.phase] ?: "⏳  انتظار"
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Sfc), border = BorderStroke(1.dp, Border)) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(phaseLabel, color = Cyan.copy(alpha = alpha), fontWeight = FontWeight.Bold)
            Text(s.message, color = Color.White, fontSize = 14.sp)
            LinearProgressIndicator(
                progress = { s.percent / 100f },
                modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                color = Cyan, trackColor = Border
            )
            Text("${s.percent}%", color = Muted, fontSize = 12.sp)
        }
    }
}

// ════════════════════════════════════════════
//  LOG CARD
// ════════════════════════════════════════════
@Composable
fun LogCard(logs: List<String>) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF060A10)),
        border = BorderStroke(1.dp, Border)) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(bottom = 10.dp)) {
                Box(Modifier.size(7.dp).background(Green, CircleShape))
                Text("سجل العمليات", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            if (logs.isEmpty()) Text("سيظهر السجل هنا...", color = Muted, fontSize = 12.sp)
            else logs.takeLast(12).forEach {
                Text(it, color = Color(0xFF7DD3FC), fontSize = 11.sp, fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(bottom = 3.dp))
            }
        }
    }
}

// ════════════════════════════════════════════
//  SUCCESS CARD
// ════════════════════════════════════════════
@Composable
fun SuccessCard(s: BuildUiState.Success, ctx: Context) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0A1F12)),
        border = BorderStroke(1.dp, Color(0xFF1A4A2A))) {
        Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("✅", fontSize = 50.sp)
            Text("اكتمل البناء بنجاح!", color = Green, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf("⏱ ${s.duration}", "📦 ${s.apkSize}", "🆔 #${s.runId.take(6)}").forEach { chip ->
                    Box(Modifier.background(Color(0xFF0D2E1A), RoundedCornerShape(99.dp)).padding(horizontal = 10.dp, vertical = 4.dp)) {
                        Text(chip, color = Green, fontSize = 12.sp)
                    }
                }
            }
            Button(
                onClick = { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(s.githubUrl))) },
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Green)
            ) { Text("📥  تنزيل APK من GitHub", color = Color.Black, fontWeight = FontWeight.ExtraBold) }
        }
    }
}

// ════════════════════════════════════════════
//  ERROR BANNER
// ════════════════════════════════════════════
@Composable
fun ErrorBanner(message: String) {
    Row(Modifier.fillMaxWidth()
        .background(Color(0xFF2E0D0D), RoundedCornerShape(12.dp))
        .border(BorderStroke(1.dp, Color(0xFF5A1A1A)), RoundedCornerShape(12.dp))
        .padding(14.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("✕", color = Red, fontSize = 16.sp)
        Text(message, color = Red, fontSize = 13.sp, modifier = Modifier.weight(1f))
    }
}

// ════════════════════════════════════════════
//  HISTORY SCREEN
// ════════════════════════════════════════════
@Composable
fun HistoryScreen(vm: MainViewModel) {
    val history by vm.history.collectAsStateWithLifecycle()
    val context  = LocalContext.current
    Column(Modifier.fillMaxSize().background(BgDark).padding(20.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 20.dp),
            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("السجل", fontSize = 26.sp, fontWeight = FontWeight.Black, color = Color.White)
                Text("${history.size} بناء", fontSize = 13.sp, color = Muted)
            }
            if (history.isNotEmpty()) TextButton(onClick = { vm.clearHistory() }) {
                Text("مسح الكل", color = Red, fontSize = 13.sp)
            }
        }
        if (history.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("📋", fontSize = 48.sp)
                    Text("لا يوجد سجل بعد", color = Muted)
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(history) { b ->
                    val ok = b.status == "success"
                    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = Sfc),
                        border = BorderStroke(1.dp, Border)) {
                        Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically) {
                            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(38.dp).background(if (ok) Color(0xFF0D2E1A) else Color(0xFF2E0D0D), CircleShape),
                                    contentAlignment = Alignment.Center) {
                                    Text(if (ok) "✓" else "✕", color = if (ok) Green else Red, fontWeight = FontWeight.Black)
                                }
                                Column {
                                    Text(b.fileName, color = Color.White, fontWeight = FontWeight.SemiBold,
                                        fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text("${b.date}  ·  ${b.duration}", color = Muted, fontSize = 12.sp)
                                }
                            }
                            if (ok && b.githubUrl != null) {
                                IconButton(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(b.githubUrl))) }) {
                                    Icon(Icons.Default.Download, null, tint = Cyan)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ════════════════════════════════════════════
//  HELPERS
// ════════════════════════════════════════════
fun getFileName(ctx: Context, uri: Uri): String = try {
    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        val idx = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
        c.moveToFirst(); c.getString(idx)
    } ?: "project.zip"
} catch (e: Exception) { "project.zip" }

// ════════════════════════════════════════════
//  THEME
// ════════════════════════════════════════════
@Composable
fun AppTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(primary = Cyan, background = BgDark, surface = Sfc),
    content = content
)
