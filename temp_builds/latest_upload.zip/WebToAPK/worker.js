// ════════════════════════════════════════════════════════════════
//  Cloudflare Worker — WebToAPK
//
//  المتغيرات البيئية المطلوبة (wrangler secret put):
//    GITHUB_TOKEN          — PAT (scopes: repo, workflow)
//    GITHUB_OWNER          — اسم صاحب المستودع
//    GITHUB_REPO           — اسم المستودع
//    SECRET_KEY            — مفتاح API لحماية الـWorker
//    WORKER_CALLBACK_SECRET — سر التحقق من callback الـworkflow
//
//  KV Namespace مطلوب: RATE_LIMIT_KV (bind في wrangler.toml)
// ════════════════════════════════════════════════════════════════

const CONFIG = {
  MAX_BUILDS_PER_DAY: 10,         // حد الاستخدام اليومي لكل مستخدم
  MAX_CONCURRENT:     3,          // حد التزامن على المستودع
  ARTIFACT_TTL_DAYS:  7,
};

// ════════════════════════════════════════════════════════════════
//  Entry Point
// ════════════════════════════════════════════════════════════════
export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    const cors = {
      'Access-Control-Allow-Origin':  '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, X-Secret-Key',
    };

    if (request.method === 'OPTIONS') {
      return new Response(null, { status: 204, headers: cors });
    }

    try {
      // ── Router ────────────────────────────────────────────────
      if (url.pathname === '/trigger'  && request.method === 'POST')
        return withCors(await handleTrigger(request, env), cors);

      if (url.pathname === '/status'   && request.method === 'GET')
        return withCors(await handleStatus(request, env), cors);

      if (url.pathname === '/callback' && request.method === 'POST')
        return withCors(await handleCallback(request, env), cors);

      if (url.pathname === '/health'   && request.method === 'GET')
        return withCors(json({ ok: true, ts: Date.now() }), cors);

      return withCors(json({ error: 'Not found' }, 404), cors);

    } catch (err) {
      console.error('Worker error:', err);
      return withCors(json({ error: 'Internal error', detail: err.message }, 500), cors);
    }
  }
};

// ════════════════════════════════════════════════════════════════
//  POST /trigger — تشغيل بناء جديد
// ════════════════════════════════════════════════════════════════
async function handleTrigger(request, env) {

  // ── التحقق من API Key ────────────────────────────────────────
  const key = request.headers.get('X-Secret-Key') || '';
  if (!env.SECRET_KEY || key !== env.SECRET_KEY) {
    return json({ error: 'Unauthorized' }, 401);
  }

  // ── قراءة الـBody ────────────────────────────────────────────
  let body;
  try { body = await request.json(); }
  catch { return json({ error: 'Invalid JSON' }, 400); }

  const zipUrl    = String(body?.zip_url   || '').trim();
  const buildType = String(body?.build_type || 'debug').trim();
  const clientId  = getClientId(request);  // للـrate limiting

  // ── التحقق من zip_url ────────────────────────────────────────
  if (!zipUrl.startsWith('https://')) {
    return json({ error: 'zip_url يجب أن يبدأ بـ https://' }, 400);
  }

  // ── Rate Limiting ─────────────────────────────────────────────
  if (env.RATE_LIMIT_KV) {
    const limited = await checkRateLimit(env.RATE_LIMIT_KV, clientId);
    if (limited) {
      return json({
        error: `تجاوزت الحد اليومي (${CONFIG.MAX_BUILDS_PER_DAY} بناء/يوم)`,
        retry_after: 'غداً'
      }, 429);
    }
    await incrementRateLimit(env.RATE_LIMIT_KV, clientId);
  }

  // ── إرسال repository_dispatch إلى GitHub ────────────────────
  const dispatchUrl =
    `https://api.github.com/repos/${env.GITHUB_OWNER}/${env.GITHUB_REPO}/dispatches`;

  const ghResp = await fetch(dispatchUrl, {
    method:  'POST',
    headers: {
      'Authorization': `token ${env.GITHUB_TOKEN}`,
      'Accept':        'application/vnd.github+json',
      'Content-Type':  'application/json',
      'User-Agent':    'webtopack-worker/1.0',
    },
    body: JSON.stringify({
      event_type: 'build-from-zip',
      client_payload: {
        zip_url:    zipUrl,
        build_type: buildType,
        client_id:  clientId,
        triggered_at: new Date().toISOString(),
      }
    })
  });

  if (ghResp.status !== 204) {
    const errText = await ghResp.text().catch(() => '');
    console.error('GitHub dispatch error:', ghResp.status, errText);
    return json({
      error:  'فشل تشغيل البناء عبر GitHub',
      status: ghResp.status,
    }, 502);
  }

  // ── جلب run_id بعد تأخير قصير ───────────────────────────────
  await sleep(2500);
  const runId = await getLatestRunId(env);

  // ── حفظ حالة البناء في KV ────────────────────────────────────
  if (env.RATE_LIMIT_KV && runId) {
    await env.RATE_LIMIT_KV.put(
      `run:${runId}`,
      JSON.stringify({ status: 'triggered', zip_url: zipUrl, build_type: buildType, client_id: clientId }),
      { expirationTtl: 86400 }  // 24 ساعة
    );
  }

  return json({
    ok:         true,
    run_id:     runId,
    build_type: buildType,
    status_url: runId
      ? `https://github.com/${env.GITHUB_OWNER}/${env.GITHUB_REPO}/actions/runs/${runId}`
      : null,
    message: 'تم تشغيل البناء بنجاح'
  });
}

// ════════════════════════════════════════════════════════════════
//  GET /status?run_id=xxx — حالة البناء
// ════════════════════════════════════════════════════════════════
async function handleStatus(request, env) {

  const key = request.headers.get('X-Secret-Key') || '';
  if (key !== env.SECRET_KEY) return json({ error: 'Unauthorized' }, 401);

  const url   = new URL(request.url);
  const runId = url.searchParams.get('run_id');

  if (!runId) {
    // إعادة آخر run
    const latest = await getLatestRunId(env);
    if (!latest) return json({ error: 'لا يوجد بناء حديث' }, 404);
    return fetchAndReturnRunStatus(latest, env);
  }

  return fetchAndReturnRunStatus(runId, env);
}

async function fetchAndReturnRunStatus(runId, env) {
  const resp = await fetch(
    `https://api.github.com/repos/${env.GITHUB_OWNER}/${env.GITHUB_REPO}/actions/runs/${runId}`,
    { headers: ghHeaders(env) }
  );

  if (resp.status === 404) return json({ error: 'Run غير موجود', run_id: runId }, 404);
  if (!resp.ok)            return json({ error: 'GitHub API error', status: resp.status }, 502);

  const run = await resp.json();

  // جلب artifact_url إذا اكتمل البناء بنجاح
  let artifactUrl = null;
  if (run.status === 'completed' && run.conclusion === 'success') {
    artifactUrl = await getArtifactUrl(runId, env);
  }

  // رسالة خطأ مقروءة
  let errorMessage = null;
  if (run.conclusion === 'failure') {
    errorMessage = mapFailureHint(run);
  }

  return json({
    ok:           true,
    run_id:       run.id,
    status:       run.status,       // queued | in_progress | completed
    conclusion:   run.conclusion,   // success | failure | cancelled | null
    started_at:   run.run_started_at,
    updated_at:   run.updated_at,
    html_url:     run.html_url,
    artifact_url: artifactUrl,
    error_hint:   errorMessage,
  });
}

// ════════════════════════════════════════════════════════════════
//  POST /callback — يستقبل إشعار من GitHub Actions
// ════════════════════════════════════════════════════════════════
async function handleCallback(request, env) {

  // التحقق من السر
  const secret = request.headers.get('X-Callback-Secret') || '';
  if (!env.WORKER_CALLBACK_SECRET || secret !== env.WORKER_CALLBACK_SECRET) {
    return json({ error: 'Unauthorized callback' }, 401);
  }

  let body;
  try { body = await request.json(); }
  catch { return json({ error: 'Invalid JSON' }, 400); }

  const { run_id, status, apk_size, html_url, logs_url } = body;

  // تخزين النتيجة في KV (لـpolling بدون استعلام GitHub)
  if (env.RATE_LIMIT_KV && run_id) {
    await env.RATE_LIMIT_KV.put(
      `result:${run_id}`,
      JSON.stringify({ status, apk_size, html_url, logs_url, finished_at: new Date().toISOString() }),
      { expirationTtl: 7 * 86400 }  // 7 أيام
    );
  }

  console.log(`Callback received: run=${run_id} status=${status}`);
  return json({ ok: true, message: 'Callback received' });
}

// ════════════════════════════════════════════════════════════════
//  Rate Limiting (Cloudflare KV)
// ════════════════════════════════════════════════════════════════
async function checkRateLimit(kv, clientId) {
  try {
    const key  = `rl:${clientId}:${todayKey()}`;
    const val  = await kv.get(key);
    const count = val ? parseInt(val) : 0;
    return count >= CONFIG.MAX_BUILDS_PER_DAY;
  } catch { return false; }
}

async function incrementRateLimit(kv, clientId) {
  try {
    const key   = `rl:${clientId}:${todayKey()}`;
    const val   = await kv.get(key);
    const count = (val ? parseInt(val) : 0) + 1;
    // ينتهي في منتصف الليل (86400 ثانية)
    await kv.put(key, String(count), { expirationTtl: 86400 });
  } catch { /* غير حرج */ }
}

// ════════════════════════════════════════════════════════════════
//  GitHub Helpers
// ════════════════════════════════════════════════════════════════
async function getLatestRunId(env) {
  try {
    const resp = await fetch(
      `https://api.github.com/repos/${env.GITHUB_OWNER}/${env.GITHUB_REPO}/actions/runs?per_page=1&event=repository_dispatch`,
      { headers: ghHeaders(env) }
    );
    if (!resp.ok) return null;
    const data = await resp.json();
    return data?.workflow_runs?.[0]?.id?.toString() ?? null;
  } catch { return null; }
}

async function getArtifactUrl(runId, env) {
  try {
    const resp = await fetch(
      `https://api.github.com/repos/${env.GITHUB_OWNER}/${env.GITHUB_REPO}/actions/runs/${runId}/artifacts`,
      { headers: ghHeaders(env) }
    );
    if (!resp.ok) return null;
    const data = await resp.json();
    const art  = data?.artifacts?.find(a => a.name?.includes('apk'));
    if (!art) return null;
    return `https://github.com/${env.GITHUB_OWNER}/${env.GITHUB_REPO}/actions/runs/${runId}/artifacts/${art.id}`;
  } catch { return null; }
}

function mapFailureHint(run) {
  // تلميحات مبنية على اسم الـrun أو التوقيت
  if (run.run_started_at) {
    const elapsed = (new Date() - new Date(run.run_started_at)) / 1000;
    if (elapsed < 60) return 'فشل سريع — تحقق من وجود index.html وامتدادات الملفات';
    if (elapsed > 900) return 'انتهت مهلة البناء — تحقق من حجم الملفات وإعدادات Gradle';
  }
  return 'فشل البناء — راجع سجل GitHub Actions للتفاصيل';
}

function ghHeaders(env) {
  return {
    'Authorization': `token ${env.GITHUB_TOKEN}`,
    'Accept':        'application/vnd.github+json',
    'User-Agent':    'webtopack-worker/1.0',
  };
}

// ════════════════════════════════════════════════════════════════
//  Utilities
// ════════════════════════════════════════════════════════════════
function getClientId(request) {
  return request.headers.get('CF-Connecting-IP')
    || request.headers.get('X-Forwarded-For')?.split(',')[0]?.trim()
    || 'unknown';
}

function todayKey() {
  return new Date().toISOString().slice(0, 10); // YYYY-MM-DD
}

function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

function json(data, status = 200) {
  return new Response(JSON.stringify(data, null, 2), {
    status,
    headers: { 'Content-Type': 'application/json' }
  });
}

function withCors(response, corsHeaders) {
  const res = new Response(response.body, response);
  Object.entries(corsHeaders).forEach(([k, v]) => res.headers.set(k, v));
  return res;
}
